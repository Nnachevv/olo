#pragma once
#include <vector>
#include <string>
#include <unordered_set>
using namespace std;
class Graph
{
public:
	Graph();
	~Graph();

	struct Villige {
		string villige_name;
		string key_name;
		string key_requremnt;
	};
	int vertex;
	vector<string>* adjecent_graphs;
	
	void add_edge(pair<string, int>  st, pair<string, int>  edge);
	
};

