#include "Graph.h"



Graph::Graph()
{
}


Graph::~Graph()
{
}

void Graph::add_edge(pair<string,int> st, pair<string, int>  edge)
{
	adjecent_graphs[st.second].push_back(edge.first);


}
