#include <string>
#include "Map.h"
#include <fstream>
#include <iostream>
#include <string>
using namespace std;
int main()
{
	//C:\\Users\\Nnachev\\source\\repos\\Homework3\\Homework3\\
	
	Map * map = new Map();



	std::ifstream file("C:\\Users\\Nnachev\\source\\repos\\Homework3\\Homework3\\file.txt");
	std::string str;
	bool zones_keys = false;
	while (std::getline(file, str))
	{
		if (str == "[zones]")
		{
			zones_keys = true;
		}
		else if (str == "[keys]" || str=="")
		{
			zones_keys = false;
		}
		else if (zones_keys==true)
		{
			std::string firstWord = str.substr(0, str.find(" "));
			str = str.substr(firstWord.size()+4, str.find(";"));
			std::string second_word = str.substr(0, str.find(" "));
			map->add_villege(firstWord);

			if (str.size()!=second_word.size())
			{
				str = str.substr(second_word.size()+1, str.find(";"));
				std::string  key= str.substr(1, str.find("]")-1);
				map->add_villege(second_word);
				map->add_edges(firstWord, second_word,key);
				continue;
			}
			else
			{
				second_word = str.substr(0, str.find(";"));

				map->add_villege(second_word);
				map->add_edges(firstWord, second_word);
			}
			

		}
		else if (zones_keys==false)
		{
			std::string key = str.substr(0, str.find(" -> "));
			str= str.substr(key.size()+4, str.find(" -> "));
			map->add_key(str, key);
		}
	}
	std::string start_zone;
	std::cin >> start_zone;
	map->find_path(start_zone);
	delete map;
}