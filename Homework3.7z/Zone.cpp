#include "Zone.h"
#include <vector>
#include <map>

Zone::Zone(std::string name,int index)
{
	this->name = name;
	key_name = "[NONE]";
	this->index = index;
}

Zone::Zone()
{
}

Zone::~Zone()
{
}

void Zone::add_key(std::string key_name)
{
	this->key_name = key_name;
}

void Zone::add_edges(Zone & zones, std::string key)
{
	
	adjecent.insert(make_pair(&zones, key));

}



void Zone::DFS(int size,bool * visited)
{
	visited[index] = true;
	for (auto i = adjecent.begin(); i != adjecent.end(); i++)
	{
		DFSUtill(i->first->index,visited);
	}
	
}

void Zone::DFSUtill(int current_index, bool * visited)
{
	visited[index] = true;
	for (auto i = adjecent.begin(); i != adjecent.end(); i++)
	{
		if (visited[i->first->index]!=true)
		{
			i->first->DFSUtill(i->first->index, visited);
		}
	}
}
void Zone::save_unvisited(ofstream & file,bool * visited)
{
	queue<Zone*> que;
	if (key_name!="[NONE]")
	{
		file << name << "[label = \"" << name << "\\" << key_name << "\", color = red, style = filled, fillcolor = \"#ffefef\"]"<<std::endl;
	}
	else
	{
		file << name << "[color = red, style = filled, fillcolor = \"#ffefef\"]"<<std::endl;
	}
	
	for (auto i = adjecent.begin(); i != adjecent.end(); i++)
	{
		if (!visited[i->first->index])
		{
			if (i->first->key_name != "[NONE]")
			{
				file << i->first->name << "[label = \"" << i->first->name << "\\l" << i->first->key_name << "\", color = red, style = filled, fillcolor = \"#ffefef\"]" << std::endl;
			}
			else
			{
				file << i->first->name << "[color = red, style = filled, fillcolor = \"#ffefef\"]" << std::endl;
			}
			que.push(i->first);
			visited[i->first->index] = true;
		}
		file << name << " -> " << i->first->name << std::endl;;
	}
	while (!que.empty())
	{
		Zone* current_zone = que.front();
		que.pop();
		for (auto i =current_zone->adjecent.begin(); i != current_zone->adjecent.end(); i++)
		{

			if (!visited[i->first->index])
			{
				if (i->first->key_name != "[NONE]")
				{
					file << i->first->name << "[label = \"" << i->first->name << "\\" << i->first->key_name << "\", color = red, style = filled, fillcolor = \"#ffefef\"]"<<std::endl;
				}
				else
				{
					file << i->first->name << "[color = red, style = filled, fillcolor = \"#ffefef\"]"<<std::endl;
				}
				que.push(i->first);
				visited[i->first->index] = true;
			}
			file << current_zone << " -> " << i->first->name << std::endl;;

		}
	}
}

void Zone::BFS(bool * visited,ofstream & file)
{
	list<pair<Zone*,string>> list_zones_visited;
	set<string> keys;
	if (key_name!="[NONE]")
	{
		keys.insert(key_name);
	}
	visited[index] = true;


	map<string, Zone*> unvisited;
	for (auto i = adjecent.begin(); i != adjecent.end(); i++)
	{
		if (i->second != "[NONE]" && !visited[i->first->index])
		{
			if (keys.find(i->second) != keys.end())
			{
				visited[i->first->index] = true;
				list_zones_visited.push_back(*i);
				file << name << " -> " << i->first->name << "[label=\"" << i->second << "\"]" << std::endl;
			}
			else
			{
				unvisited.insert(make_pair(i->second, i->first));
				file << name << " -> " << i->first->name << "[label=\"" << i->second << "\"]" << std::endl;
				continue;
			}
			
		}
		else if (!visited[i->first->index])
		{
			visited[i->first->index] = true;
			list_zones_visited.push_back(*i);
			file << name << " -> " << i->first->name << std::endl;
		}
		else if (i->second != "[NONE]")
		{
			file << name << " -> " << i->first->name << "[label=\"" << i->second << "\"]" << std::endl;
		}

		if (i->first->key_name != "[NONE]")
		{
			keys.insert(i->first->key_name);
			file << i->first->name << "[label=\"" << i->first->name << "\\l" << i->first->key_name << "\"]"<<std::endl;
			if (unvisited.find(i->first->key_name) != unvisited.end())
			{
				list_zones_visited.push_back(make_pair(unvisited.find(i->first->key_name)->second, i->first->key_name));
				unvisited.erase(i->first->key_name);

			}
		}
		
	
	}
	while (!list_zones_visited.empty())
	{
	
		pair<Zone*, string > current_zone = list_zones_visited.front();
		list_zones_visited.pop_front();

		for (auto i = current_zone.first->adjecent.begin(); i != current_zone.first->adjecent.end(); i++)
		{

			
			if (i->second != "[NONE]" && !visited[i->first->index])
			{
				if (keys.find(i->second) != keys.end())
				{
					visited[i->first->index] = true;
					list_zones_visited.push_back(*i);
					file<<current_zone.first->name <<" -> "<<i->first->name<<"[label=\"" <<i->second<<"\"]"<<std::endl;

				}
				else
				{
				
					unvisited.insert(make_pair(i->second,i->first));
					file << current_zone.first->name << " -> " << i->first->name << "[label=\"" << i->second << "\"]" << std::endl;
					continue;
				}

				if (i->first->adjecent.find(make_pair(current_zone.first,current_zone.second))!=i->first->adjecent.end())
				{
					//TO DO
				}
			}
			else if(!visited[i->first->index])
			{
				visited[i->first->index] = true;
				list_zones_visited.push_back(*i);
				file << current_zone.first->name << " -> " << i->first->name << std::endl;
			}
			else if(i->second != "[NONE]")
			{
				file << current_zone.first->name << " -> " << i->first->name << "[label=\"" << i->second << "\"]" << std::endl;
			}



			if (i->first->key_name != "[NONE]")
			{
				keys.insert(i->first->key_name);
				file << i->first->name << "[label=\"" << i->first->name << "\\l" << i->first->key_name << "\"]"<<std::endl;
				if (unvisited.find(i->first->key_name) != unvisited.end())
				{
					list_zones_visited.push_back(make_pair(unvisited.find(i->first->key_name)->second, i->first->key_name));
					unvisited.erase(i->first->key_name);
				}
			}

		}


	}







	list_zones_visited.clear();
	for (auto i = unvisited.begin(); i != unvisited.end(); i++)
	{
		list_zones_visited.push_back(make_pair(i->second, i->first));
	}
	while (!list_zones_visited.empty())
	{
		pair<Zone*, string > current_zone = list_zones_visited.front();
		list_zones_visited.pop_front();
		if (current_zone.first->key_name!="[NONE]")
		{
			file << current_zone.first->name << "[label=\""<<current_zone.first->name<<"\\l"<<current_zone.first->key_name <<"\"color = red, style = filled, fillcolor = \"#ffefef\"]" << std::endl;
		}
		else
		{
			file << current_zone.first->name << "[color = red, style = filled, fillcolor = \"#ffefef\"]" << std::endl;
		}


		for (auto i = current_zone.first->adjecent.begin(); i != current_zone.first->adjecent.end(); i++)
		{
			if (!visited[i->first->index])
			{
				visited[i->first->index] = true;
				list_zones_visited.push_back(make_pair(i->first,i->second));
			}
			file << current_zone.first->name << " -> " << i->first->name << std::endl;
		}
	}
}


