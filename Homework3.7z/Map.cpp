#include "Map.h"



Map::Map()
{
	index = 0;
	file.open("zones.txt");
	file << "digraph {\n" ;

}


Map::~Map()
{
	file << "}";
}

void Map::add_villege(std::string name)
{
	if (zones.find(name)==zones.end())
	{
		Zone * zone = new Zone(name,index);
		zones_index[index] = name;
		index++;
		zones[name] = *zone;
		delete zone;
	}
}

void Map::add_edges(std::string first_villige, std::string second_villige, std::string key)
{
	zones[first_villige].add_edges(zones[second_villige], key);
}




void Map::add_key(std::string villige, std::string key_name)
{
	zones[villige].add_key(key_name);

}

void Map::find_path(std::string start)
{
	bool* visited = new bool[zones.size()];
	
	for (int i = 0; i < zones.size(); i++)
	{
		visited[i] = false;
	}
	zones[start].BFS(visited,file);
	for (int i = 0; i < zones.size(); i++)
	{
		visited[i] = false;
	}
	zones[start].DFS(zones.size(), visited);
	for (int i = 0; i < zones.size(); i++)
	{
		if (visited[i] == 0)
		{
			std::string s = zones_index[i];
			zones[s].save_unvisited(file,visited);
		}
	}
}



