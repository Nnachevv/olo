#pragma once
#include <iostream>
#include <string>
#include <set>
#include <list>
#include <fstream>
#include <queue>
using namespace std;
class Zone
{
public:
	Zone(std::string name,int);
	Zone();
	~Zone();

	void add_key(std::string key_name);
	void add_edges( Zone & zones,std::string key);

	void DFS(int size,bool * visited);
	void BFS(bool * visited,ofstream & file);
	const std::string get_name()const { return name; };
	void save_unvisited(ofstream & file, bool * visited);

private:
	std::string name;
	int index;
	std::string key_name;
	void DFSUtill(int current_index,bool * visited);
	set<pair<Zone*, string>> adjecent;
};

