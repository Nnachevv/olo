#pragma once
#include <string>
#include <vector>
#include <unordered_set>
#include <set>
#include "Zone.h"
#include <map>
#include <fstream>
using namespace std;
class Map
{
public:
	Map();
	~Map();
	void add_villege(std::string name);
	void add_edges(std::string first_villige, std::string second_villige, std::string key="[NONE]");
	void add_key(std::string villige, std::string key_name);
	void find_path(std::string start);
	ofstream file;
private:



	map<string,Zone> zones;
	map<int, string> zones_index;
	int index;
};

